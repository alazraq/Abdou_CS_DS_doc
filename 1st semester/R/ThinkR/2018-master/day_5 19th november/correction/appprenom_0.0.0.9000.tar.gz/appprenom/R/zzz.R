globalVariables(c("%>%","prenoms","name","sex","group_by",'year','summarise','n','ungroup',"complete","coord_cartesian",
                  "ggplot","aes","geom_line",

                  "total","pull"))
